package com.domain;

import java.util.Date;
import java.util.List;

public class Conversation {
	private int conversationID;
    private User user;
    private CustomerServiceRepresentative csr;
    private Date startTime;
    private Date endTime;
    public int getConversationID() {
		return conversationID;
	}
	public void setConversationID(int conversationID) {
		this.conversationID = conversationID;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public CustomerServiceRepresentative getCsr() {
		return csr;
	}
	public void setCsr(CustomerServiceRepresentative csr) {
		this.csr = csr;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getSentiment() {
		return sentiment;
	}
	public void setSentiment(String sentiment) {
		this.sentiment = sentiment;
	}
	public List<ConversationMessage> getMessages() {
		return messages;
	}
	public void setMessages(List<ConversationMessage> messages) {
		this.messages = messages;
	}
	private String sentiment;
    private List<ConversationMessage> messages;
}
