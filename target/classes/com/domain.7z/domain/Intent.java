package com.domain;

import java.util.List;

public class Intent {
	 private int intentID;
	    private String intentName;
	    private String description;
	    private List<Entity> entities;
	    private List<Response> responses;
		public int getIntentID() {
			return intentID;
		}
		public void setIntentID(int intentID) {
			this.intentID = intentID;
		}
		public String getIntentName() {
			return intentName;
		}
		public void setIntentName(String intentName) {
			this.intentName = intentName;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public List<Entity> getEntities() {
			return entities;
		}
		public void setEntities(List<Entity> entities) {
			this.entities = entities;
		}
		public List<Response> getResponses() {
			return responses;
		}
		public void setResponses(List<Response> responses) {
			this.responses = responses;
		}
}
