package com.domain;

public class CustomerServiceRepresentative {
	 private int csrID;
	    private String csrName;
	    private String csrEmail;
		public int getCsrID() {
			return csrID;
		}
		public void setCsrID(int csrID) {
			this.csrID = csrID;
		}
		public String getCsrName() {
			return csrName;
		}
		public void setCsrName(String csrName) {
			this.csrName = csrName;
		}
		public String getCsrEmail() {
			return csrEmail;
		}
		public void setCsrEmail(String csrEmail) {
			this.csrEmail = csrEmail;
		}
	    
}
