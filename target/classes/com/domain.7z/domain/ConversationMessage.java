package com.domain;

import java.util.Date;

public class ConversationMessage {
	 private int messageID;
	    private Conversation conversation;
	    private String sender;
	    private String messageContent;
	    private Date timestamp;
		public int getMessageID() {
			return messageID;
		}
		public void setMessageID(int messageID) {
			this.messageID = messageID;
		}
		public Conversation getConversation() {
			return conversation;
		}
		public void setConversation(Conversation conversation) {
			this.conversation = conversation;
		}
		public String getSender() {
			return sender;
		}
		public void setSender(String sender) {
			this.sender = sender;
		}
		public String getMessageContent() {
			return messageContent;
		}
		public void setMessageContent(String messageContent) {
			this.messageContent = messageContent;
		}
		public Date getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(Date timestamp) {
			this.timestamp = timestamp;
		}
}
